package com.flightbooking.app.airport;

public interface AirportServiceImpl {
}
