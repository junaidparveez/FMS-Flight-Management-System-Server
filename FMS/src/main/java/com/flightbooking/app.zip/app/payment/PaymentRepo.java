package com.flightbooking.app.payment;

public interface PaymentRepo {
}
