package com.flightbooking.app.booking;

public interface BookingServiceImpl {
}
