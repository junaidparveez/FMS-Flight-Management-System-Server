package com.flightbooking.app.payment;

public class PaymentController {
}
