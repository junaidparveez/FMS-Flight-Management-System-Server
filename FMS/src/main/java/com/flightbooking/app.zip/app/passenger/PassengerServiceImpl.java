package com.flightbooking.app.passenger;

public interface PassengerServiceImpl {
}
