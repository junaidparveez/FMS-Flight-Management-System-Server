package com.flightbooking.app.payment;

public interface PaymentServiceImpl {
}
