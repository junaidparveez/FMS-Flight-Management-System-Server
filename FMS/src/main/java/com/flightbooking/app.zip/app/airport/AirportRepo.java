package com.flightbooking.app.airport;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AirportRepo  extends JpaRepository<Airport,Integer> {

}
