package com.flightbooking.app.airline;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AirlineRepo extends JpaRepository<Airline,Integer> {

}
