package com.flightbooking.app.flight;

public class FlightController {
}
