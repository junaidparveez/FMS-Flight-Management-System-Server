package com.flightbooking.app.flight;

public interface FlightServiceImpl {
}
