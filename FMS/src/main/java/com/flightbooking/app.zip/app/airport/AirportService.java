package com.flightbooking.app.airport;

public class AirportService {
}
