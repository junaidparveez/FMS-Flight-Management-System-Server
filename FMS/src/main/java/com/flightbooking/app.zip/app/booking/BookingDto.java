package com.flightbooking.app.booking;

public class BookingDto {
}
