package com.flightbooking.app.passenger;

public class PassengerService {
}
