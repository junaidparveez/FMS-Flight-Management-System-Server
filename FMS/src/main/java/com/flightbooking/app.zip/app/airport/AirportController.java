package com.flightbooking.app.airport;

public class AirportController {
}
