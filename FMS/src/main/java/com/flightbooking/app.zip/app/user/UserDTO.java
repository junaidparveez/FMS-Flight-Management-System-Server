package com.flightbooking.app.user;

public class UserDTO {
}
